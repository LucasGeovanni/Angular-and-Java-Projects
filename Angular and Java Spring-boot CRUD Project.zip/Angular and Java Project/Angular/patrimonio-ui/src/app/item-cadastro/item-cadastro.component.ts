import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ItemService } from './../item/item.service';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { Injectable } from '@angular/core';



@Component({
  selector: 'app-item-cadastro',
  templateUrl: './item-cadastro.component.html',
  styleUrls: ['./item-cadastro.component.css']
})
@Injectable()

export class ItemCadastroComponent implements OnInit {

  msgs: any[];
  confirmationService: any;
  itens = [];
  closeResult: string;


  constructor(private itemService: ItemService, private modalService: NgbModal) { }

  ngOnInit() {
    this.consultar();
  }

  consultar() {
    this.itemService.listar()
      .subscribe(dados => this.itens = dados);
  }

  adicionar(frm: FormControl) {
    this.itemService.adicionar(frm.value)
      .subscribe(() => {
        frm.reset();
        this.consultar();
      });
  }

  excluir(item) {
    if(confirm('Confirmar exclusção!')){
      this.itemService.deletar(item)
        .subscribe(() => {
          this.ngOnInit();

        });

    }

   
    

  }

}