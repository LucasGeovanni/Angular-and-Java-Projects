package br.com.patrimonioapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.patrimonioapi.model.Item;

public interface ItemRepository extends JpaRepository<Item, Long> {

}
